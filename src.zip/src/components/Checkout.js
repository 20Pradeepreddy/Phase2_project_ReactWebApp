const Checkout = () => {
    return(
        <div></div>
    );
}
export default Checkout;