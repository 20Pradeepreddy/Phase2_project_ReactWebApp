import React, { useState, useEffect, useContext } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { CartContext } from './CartContext';
import axios from 'axios';
import './ItemDetails.css'; 

const ItemDetails = () => {
  const { categoryType, itemId } = useParams();
  const [item, setItem] = useState('');
  const { addToCart } = useContext(CartContext);
  const navigate = useNavigate();
  let [name, setname] = useState('')

  // // useEffect(() => {
  //   fetch(`http://localhost:8000/products/${categoryType}/${itemId}`,{method:'GET'})
  //     .then(response => response.json()) .then(data=> 
          
          // console.log(item.data[0].options)
        //   {item = data;
        //     name = item.data[0].name;
        //     }
        // ) 
        // const cleanedOption = response.data.option.replace(/OrderedDict\(/g, '').replace(/\)/g, '');
        // const cleanedRentalOption = response.data.rental_option.replace(/\[OrderedDict\(/g, '[').replace(/OrderedDict\(/g, '').replace(/\)/g, '');
        // const option = JSON.parse(cleanedOption.replace(/'/g, '"'));
        // const rentalOption = JSON.parse(cleanedRentalOption.replace(/'/g, '"'));
        // console.log(response.data);
        // setItem(
        //     response.data
        //   // option,
        //   // rental_option: rentalOption
        // );

      // .catch(error => {
      //   console.error('Error fetching item details:', error);
      // });
      useEffect(() => {
        const fetchData = async () => {
          try {
            const response = await axios.get(`http://localhost:8000/products/${categoryType}/${itemId}`);
            // setCategories(response.data);
            const cleanedData = response.data.data.map(product => ({
              id: product.id,
              name: product.name,
              description : product.description,
              condition : product.condition,
              noofdays : product.noofdays,
              type: product.category,
              options : {
                color: product.options.color,
                size : product.options.size,
                image : decodeURIComponent(product.options.imageurl).replace(/^\//, '')
              },
              rentaloptions : {
                tenture : product.rentaloptions.tenture
              }
              // Decode the URL-encoded image path and remove the leading slash
            }));
            setItem(cleanedData);
            console.log(cleanedData);
          } catch (error) {
            console.error('Error fetching categories:', error);
          }
        };
    
        fetchData();
      }, []);
    
  // }, [categoryType, itemId]);
  
  console.log(name)

  const handleAddToCart = () => {
    const itemToAdd = {
      id: item.id,
      name: item.name,
      image: item.option.imageurl,
      quantity: 1
    };
  
    window.alert('Added to cart successfully!');
    addToCart(itemToAdd);
    navigate('/cart');
  };

  return (
    <div>
      <header className="header">
        <div className="header-links">
          <Link exact to="/" >RENTFURLAX</Link>
          <Link to="/login" >Login</Link>
          <Link to="/register" >Register</Link>
        </div>
      </header>
      <h1>{name}</h1>
        {/* <div className="item-details-content">
          <div className="left-content">
            <img src={item.data.options.imageurl} alt={item.name} />
            <button onClick={handleAddToCart} >Add to cart</button>
          </div>
          <div className="right-content">
            <h1>{item.data.name}</h1>
            <p>{item.data.description}</p>
            <div>Color: {item.data.options.color}</div>
            <div>Size: {item.data.options.size}</div>
            Rental Options:
            <ul>
              {item.data.rentaloptions.map(option => (
                <li key={option.tenure}>
                  {option.tenure} months : {option.ratepermonth} per month
                </li>
              ))}
            </ul>
            <div>Condition : {item.data.condition}</div>
            <div>Delivered by: {item.data.noofdays} days</div>
          </div>
        </div> */}
         <h1 className='browse-category'>{categoryType} Items on Rent</h1>
      {/* <div className="underline"></div>
      <div className="category-items-container">
      {item.map((product) => {
        return (
          <div key={product.id} className="product-item">
            <img src={product.options.imageurl} alt={product.name} />
            <div className='product-details'>
            <h3>{product.name}</h3>
            <p>{product.description}</p><br/>
            {product.id && (
              <div className="button-container">
                <Link to={`/Category/${categoryType}/${product.id}`} className="details-button">Details</Link>
              </div>
            )}
            </div>
          </div>
        );
      })}
      </div>     */}
    </div>

  );
}

export default ItemDetails;
